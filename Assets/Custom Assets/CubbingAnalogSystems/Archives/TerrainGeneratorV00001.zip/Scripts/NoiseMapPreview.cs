using UnityEngine;

public class NoiseMapPreview : MonoBehaviour
{
    [Header("Configuration")]
    public Renderer textureRenderer;
    public NoiseData noiseData;

    [Header("Dimensions")]
    [Range(10, 512)] public int mapSize = 128;

    public bool autoUpdate = true;

    public void DrawMapInEditor()
    {
        if (noiseData == null) return;

        float[,] noiseMap = Noise.GenerateNoiseMap(mapSize, mapSize, noiseData);

        // Conversion de la HeightMap en Texture2D
        Texture2D texture = new Texture2D(mapSize, mapSize);
        Color[] colourMap = new Color[mapSize * mapSize];

        for (int y = 0; y < mapSize; y++)
        {
            for (int x = 0; x < mapSize; x++)
            {
                // On utilise le mode niveaux de gris (Grayscale)
                colourMap[y * mapSize + x] = Color.Lerp(Color.black, Color.white, noiseMap[x, y]);
            }
        }

        texture.SetPixels(colourMap);
        texture.Apply();

        // Application au mat�riel (instanci� pour l'�diteur)
        textureRenderer.sharedMaterial.mainTexture = texture;
        textureRenderer.transform.localScale = new Vector3(mapSize, 1, mapSize) / 10f; // Ajuste la taille du plan
    }

    // Callback Unity appel� d�s qu'on change une valeur dans l'inspecteur
    void OnValidate()
    {
        if (autoUpdate)
        {
            DrawMapInEditor();
        }
    }
}