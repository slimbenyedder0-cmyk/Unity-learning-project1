using UnityEngine;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using System.Collections.Generic;

public class MapChunkManager : MonoBehaviour
{
    [Header("Settings")]
    public NoiseData noiseData;
    public Material terrainMaterial;

    [Header("Grid Config")]
    public int chunkCountX = 4;
    public int chunkCountZ = 4;
    public int mapChunkSize = 241;
    [Range(0, 6)] public int editorLOD = 0;

    [Header("Mesh Config")]
    public float heightMultiplier = 20f;
    public AnimationCurve heightCurve;

    public Dictionary<Vector2, TerrainChunk> chunkDictionary = new Dictionary<Vector2, TerrainChunk>();

    public void GenerateFullMap()
    {
        // Nettoyage
        chunkDictionary.Clear();
        for (int i = transform.childCount - 1; i >= 0; i--)
            DestroyImmediate(transform.GetChild(i).gameObject);

        for (int z = 0; z < chunkCountZ; z++)
        {
            for (int x = 0; x < chunkCountX; x++)
            {
                Vector2 chunkCoord = new Vector2(x, z);
                TerrainChunk newChunk = new TerrainChunk(chunkCoord, mapChunkSize, transform, terrainMaterial);
                chunkDictionary.Add(chunkCoord, newChunk);

                // Calcul de l'offset r�el pour le bruit continu
                Vector2 offset = new Vector2(x * (mapChunkSize - 1), z * (mapChunkSize - 1));
                GenerateChunkWithJob(newChunk, offset);
            }
        }
    }

    public void GenerateChunkWithJob(TerrainChunk chunk, Vector2 chunkOffset)
    {
        int totalSize = mapChunkSize * mapChunkSize;
        NativeArray<float> noiseResults = new NativeArray<float>(totalSize, Allocator.Persistent);
        NativeArray<float2> octOffsets = new NativeArray<float2>(noiseData.octaves, Allocator.Persistent);

        try
        {
            System.Random prng = new System.Random(noiseData.seed);
            for (int i = 0; i < noiseData.octaves; i++)
                octOffsets[i] = new float2(prng.Next(-100000, 100000), prng.Next(-100000, 100000));

            NoiseJob job = new NoiseJob
            {
                width = mapChunkSize,
                scale = noiseData.scale,
                octaves = noiseData.octaves,
                persistance = noiseData.persistance,
                lacunarity = noiseData.lacunarity,
                offset = new float2(chunkOffset.x, chunkOffset.y),
                octaveOffsets = octOffsets,
                result = noiseResults
            };

            JobHandle handle = job.Schedule(totalSize, 64);
            handle.Complete();

            float[,] heightMap = new float[mapChunkSize, mapChunkSize];
            for (int y = 0; y < mapChunkSize; y++)
            {
                for (int x = 0; x < mapChunkSize; x++)
                {
                    // On force l'index lin�aire strict
                    int index = y * mapChunkSize + x;
                    heightMap[x, y] = noiseResults[index];
                }
            }

            chunk.status = ChunkStatus.DataGenerated;

            // TICKET �TAPE 2 : Chargement final
            chunk.Load(heightMap, heightMultiplier, heightCurve, editorLOD);
        }
        finally
        {
            // On lib�re la m�moire UNIQUEMENT ici, une seule fois, quoi qu'il arrive
            if (noiseResults.IsCreated) noiseResults.Dispose();
            if (octOffsets.IsCreated) octOffsets.Dispose();
        }
    }
}