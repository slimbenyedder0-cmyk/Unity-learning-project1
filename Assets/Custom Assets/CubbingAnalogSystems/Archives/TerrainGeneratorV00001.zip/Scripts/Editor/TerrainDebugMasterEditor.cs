using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(TerrainDebugMaster))]
public class TerrainDebugMasterEditor : Editor
{
    public override void OnInspectorGUI()
    {
        TerrainDebugMaster debugMaster = (TerrainDebugMaster)target;

        // Bouton de g�n�ration manuelle
        GUI.backgroundColor = Color.green;
        if (GUILayout.Button("FORCE FULL GENERation", GUILayout.Height(40)))
        {
            debugMaster.Refresh(); // Utilise Refresh() au lieu de RefreshTerrain()
        }
        GUI.backgroundColor = Color.white;

        EditorGUILayout.Space();

        // Dessine l'inspecteur par d�faut (pour voir autoUpdate, showGizmos, etc.)
        if (DrawDefaultInspector())
        {
            // Utilise autoUpdate au lieu de liveUpdate
            if (debugMaster.autoUpdate)
            {
                debugMaster.Refresh();
            }
        }

        // Infos pratiques pour le debug
        if (debugMaster.chunkManager != null)
        {
            EditorGUILayout.HelpBox(
                $"Configuration actuelle :\n" +
                $"- Grille : {debugMaster.chunkManager.chunkCountX}x{debugMaster.chunkManager.chunkCountZ} chunks\n" +
                $"- R�solution : {debugMaster.chunkManager.mapChunkSize} sommets par c�t�\n" +
                $"- Total : {debugMaster.chunkManager.chunkCountX * debugMaster.chunkManager.chunkCountZ} chunks actifs",
                MessageType.Info);
        }
    }
}