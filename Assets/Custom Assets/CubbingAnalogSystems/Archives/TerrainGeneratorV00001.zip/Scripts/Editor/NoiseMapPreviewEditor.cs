using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(NoiseMapPreview))]
public class NoiseMapPreviewEditor : Editor
{
    public override void OnInspectorGUI()
    {
        NoiseMapPreview preview = (NoiseMapPreview)target;

        if (DrawDefaultInspector())
        {
            if (preview.autoUpdate)
            {
                preview.DrawMapInEditor();
            }
        }

        if (GUILayout.Button("Generate Map"))
        {
            preview.DrawMapInEditor();
        }
    }
}