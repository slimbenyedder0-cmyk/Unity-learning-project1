using UnityEngine;

public static class MeshDataGenerator
{
    // Dans MeshDataGenerator.cs
    public static MeshData GenerateTerrainMesh(float[,] heightMap, float heightMultiplier, AnimationCurve _heightCurve, int levelOfDetail)
    {
        int width = heightMap.GetLength(0); // Doit �tre 241
        int height = heightMap.GetLength(1); // Doit �tre 241

        int increment = (levelOfDetail == 0) ? 1 : levelOfDetail * 2;
        int verticesPerLine = (width - 1) / increment + 1;

        MeshData meshData = new MeshData(verticesPerLine, verticesPerLine);
        int vertexIndex = 0;

        for (int y = 0; y < height; y += increment)
        {
            for (int x = 0; x < width; x += increment)
            {

                // On s'assure que x et y ne d�passent jamais les bornes du heightMap
                float clampedX = Mathf.Clamp(x, 0, width - 1);
                float clampedY = Mathf.Clamp(y, 0, height - 1);

                float h = _heightCurve.Evaluate(heightMap[(int)clampedX, (int)clampedY]) * heightMultiplier;
                meshData.vertices[vertexIndex] = new Vector3(x, h, y);
                meshData.uvs[vertexIndex] = new Vector2(x / (float)(width - 1), y / (float)(height - 1));

                // On ne cr�e des triangles que si on n'est pas sur le bord droit/bas
                if (x < width - 1 && y < height - 1)
                {
                    // IMPORTANT : L'indexation des triangles doit suivre verticesPerLine
                    int a = vertexIndex;
                    int b = vertexIndex + 1;
                    int c = vertexIndex + verticesPerLine;
                    int d = vertexIndex + verticesPerLine + 1;

                    meshData.AddTriangle(a, d, c);
                    meshData.AddTriangle(d, a, b);
                }
                vertexIndex++;
            }
        }
        return meshData;
    }
}
