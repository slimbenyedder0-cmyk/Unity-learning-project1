using UnityEngine;

[CreateAssetMenu(fileName = "UpdatableData", menuName = "Scriptable Objects/UpdatableData")]
public class UpdatableData : ScriptableObject
{
    
}
