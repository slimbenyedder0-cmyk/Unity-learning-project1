using UnityEngine;

[CreateAssetMenu(fileName = "NewNoiseData", menuName = "Terrain/NoiseData")]
public class NoiseData : ScriptableObject
{
    public float scale = 50f;
    [Range(1, 10)] public int octaves = 4;
    [Range(0, 1)] public float persistance = 0.5f;
    public float lacunarity = 2f;


    public int seed;
    public Vector2 offset;

    // Option pour le Raw Noise demand� pr�c�demment
    public bool useNormalizedMode = true;

    // Ici on va mettre l'animation curve pour la hauteur
    public AnimationCurve heightCurve = AnimationCurve.Linear(0, 0, 1, 1);

    // Pratique pour forcer l'update en �diteur
#if UNITY_EDITOR
    protected virtual void OnValidate()
    {
        if (lacunarity < 1) lacunarity = 1;
        if (octaves < 1) octaves = 1;
    }
#endif
}