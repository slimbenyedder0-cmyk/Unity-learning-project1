using UnityEngine;

public enum ChunkStatus
{
    Empty, DataGenerated, MeshLoaded, Error
}
public class TerrainChunk
{
    public ChunkStatus status = ChunkStatus.Empty;
    GameObject meshObject;
    MeshFilter meshFilter;
    MeshRenderer meshRenderer;

    public TerrainChunk(Vector2 coord, int size, Transform parent, Material material)
    {
        meshObject = new GameObject("Chunk " + coord.x + "," + coord.y);
        meshFilter = meshObject.AddComponent<MeshFilter>();
        meshRenderer = meshObject.AddComponent<MeshRenderer>();
        meshRenderer.material = material;

        // Positionnement (Size - 1 pour �viter les trous)
        meshObject.transform.position = new Vector3(coord.x * (size - 1), 0, coord.y * (size - 1));
        meshObject.transform.parent = parent;
    }

    
    public void Load(float[,] heightMap, float multiplier, AnimationCurve curve, int lod)
    {
        try
        {
            MeshData meshData = MeshDataGenerator.GenerateTerrainMesh(heightMap, multiplier, curve, lod);
            meshFilter.sharedMesh = meshData.CreateMesh();
            status = ChunkStatus.MeshLoaded; // Ticket Valid�
        }
        catch (System.Exception e)
        {
            Debug.LogError($"Erreur chargement Mesh: {e.Message}");
            status = ChunkStatus.Error;
        }
    }
}