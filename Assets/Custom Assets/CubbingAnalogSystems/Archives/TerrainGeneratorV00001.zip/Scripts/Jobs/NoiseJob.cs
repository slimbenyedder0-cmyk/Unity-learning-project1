using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

[BurstCompile]
public struct NoiseJob : IJobParallelFor
{
    [ReadOnly] public int width;
    [ReadOnly] public float scale;
    [ReadOnly] public int octaves;
    [ReadOnly] public float persistance;
    [ReadOnly] public float lacunarity;
    [ReadOnly] public float2 offset;
    [ReadOnly] public NativeArray<float2> octaveOffsets;

    public NativeArray<float> result;

    // Dans NoiseJob.cs
    public void Execute(int index)
    {
        // Calcul de x et y � partir de l'index lin�aire
        int x = index % width;
        int y = index / width;

        float amplitude = 1;
        float frequency = 1;
        float noiseHeight = 0;

        for (int i = 0; i < octaves; i++)
        {
            // On ajoute l'offset ici
            float sampleX = (x + offset.x) / scale * frequency + octaveOffsets[i].x;
            float sampleY = (y + offset.y) / scale * frequency + octaveOffsets[i].y;

            float perlinValue = Mathf.PerlinNoise(sampleX, sampleY) * 2 - 1;
            noiseHeight += perlinValue * amplitude;

            amplitude *= persistance;
            frequency *= lacunarity;
        }

        result[index] = noiseHeight;
    }
}