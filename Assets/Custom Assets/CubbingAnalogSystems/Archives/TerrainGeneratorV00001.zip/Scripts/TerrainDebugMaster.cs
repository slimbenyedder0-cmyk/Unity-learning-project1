using UnityEngine;

public class TerrainDebugMaster : MonoBehaviour
{
    public MapChunkManager chunkManager;
    public bool autoUpdate = true;

    [Header("Gizmos Settings")]
    public bool showGizmos = true;
    public Color gizmoColor = Color.cyan;

    public void Refresh()
    {
        if (chunkManager != null) chunkManager.GenerateFullMap();
    }

    // Ce bloc ne sera compil� que dans l'�diteur Unity
#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        if (chunkManager == null || chunkManager.chunkDictionary == null) return;

        float size = (chunkManager.mapChunkSize - 1);

        for (int z = 0; z < chunkManager.chunkCountZ; z++)
        {
            for (int x = 0; x < chunkManager.chunkCountX; x++)
            {
                Vector2 coord = new Vector2(x, z);

                // On v�rifie si le chunk existe et on r�cup�re son ticket
                if (chunkManager.chunkDictionary.TryGetValue(coord, out TerrainChunk chunk))
                {
                    // Couleur selon l'�tape de g�n�ration (le Ticket)
                    switch (chunk.status)
                    {
                        case ChunkStatus.Empty: Gizmos.color = Color.gray; break;
                        case ChunkStatus.DataGenerated: Gizmos.color = Color.yellow; break;
                        case ChunkStatus.MeshLoaded: Gizmos.color = Color.green; break;
                        case ChunkStatus.Error: Gizmos.color = Color.red; break;
                    }
                }
                else
                {
                    Gizmos.color = Color.cyan; // Pas encore cr��
                }

                if (!showGizmos) continue;

                Vector3 centerPos = new Vector3(x * size + size / 2f, chunkManager.heightMultiplier / 2f, z * size + size / 2f);
                Vector3 boxSize = new Vector3(size, chunkManager.heightMultiplier, size);
                Gizmos.DrawWireCube(centerPos, boxSize);
            }
        }
    }
#endif
}