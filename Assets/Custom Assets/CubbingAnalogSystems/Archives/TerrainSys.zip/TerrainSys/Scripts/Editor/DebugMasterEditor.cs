using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(DebugMaster))]
public class DebugMasterEditor : Editor
{
    public override void OnInspectorGUI()
    {
        // On r�cup�re la r�f�rence du script cible
        DebugMaster debugMaster = (DebugMaster)target;

        // Si une valeur change dans l'inspecteur du DebugMaster (Width, Height, Offset...)
        if (DrawDefaultInspector())
        {
            if (debugMaster.autoUpdate)
            {
                debugMaster.ExecuteCurrentDebugMode();
            }
        }

        // On ajoute un bouton manuel en bas de l'inspecteur
        if (GUILayout.Button("G�n�rer la Map"))
        {
            debugMaster.ExecuteCurrentDebugMode();
        }
    }
}