using UnityEngine;

public static class MeshGenerator
{
    // Serais-ce d�bile de demander un return � cette fonction ?
    public static Vector3[,] GenerateMeshMapFromNoiseMap(float[,] noiseMap)
    {
        int mapWidth = noiseMap.GetLength(0);
        int mapHeight = noiseMap.GetLength(1);

        Vector3[,] meshMap = new Vector3[mapWidth, mapHeight];
        for (int i = 0; i < mapWidth; i++)
        {
            for (int j = 0; j < mapHeight; j++)
            {
                meshMap[i, j] = new Vector3(i, noiseMap[i, j], j);
            }
        }
        return meshMap;
    }
}
