using System.Runtime.InteropServices;
using UnityEngine;

[CreateAssetMenu(fileName = "NoiseData", menuName = "Scriptable Objects/NoiseData")]
public class NoiseData : UpdatableData // regardez la classe UpdatableData ci-dessus
{
    [SerializeField]
    public int Seed;
    [SerializeField]
    public float Scale = 1f;
    [SerializeField]
    public int Octaves = 1;
    [Range(0f, 1f)]
    public float Persistence = 0.5f;
    [SerializeField]
    public float Lacunarity = 2f;
    [SerializeField]
    public Vector2 Offset;

# if UNITY_EDITOR
    private void OnValidate()
    {
        if (Scale <= 0f)
        {
            Scale = 0.0001f;
        }
        if (Octaves < 1)
        {
            Octaves = 1;
        }
        if (Lacunarity < 1f)
        {
            Lacunarity = 1f;
        }
        if (Persistence < 0f)
        {
            Persistence = 0f;
        }
    }
#endif
}
