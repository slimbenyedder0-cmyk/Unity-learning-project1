using UnityEngine;

[CreateAssetMenu(fileName = "UpdatableData", menuName = "Scriptable Objects/UpdatableData")]

// UpdatableData.cs � cr�ation d'une classe abstraite d�riv�e de ScriptableObject, cette classe permet de notifier les abonn�s lorsqu'une mise � jour des donn�es se produit. En gros si un asset cr��e � partir de cette classe voit ses valeurs modifi�es, il peut notifier d'autres objets qui se sont abonn�s � cet �v�nement.
public abstract class UpdatableData : ScriptableObject
    {
        public event System.Action OnValuesUpdated;

        protected void NotifyOfValueUpdate()
        {
            OnValuesUpdated?.Invoke();
        }
    }

