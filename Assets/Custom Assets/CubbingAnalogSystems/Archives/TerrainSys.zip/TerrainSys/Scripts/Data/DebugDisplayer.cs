using UnityEngine;

public class DebugDisplayer : MonoBehaviour
{
    [SerializeField] private MeshRenderer meshRenderer;

    public void DrawMapFromNoiseMap(float[,] noiseMap)
    {
        int width = noiseMap.GetLength(0);
        int height = noiseMap.GetLength(1);

        // 1. Cr�ation de la texture
        Texture2D texture = new Texture2D(width, height);
        Color[] colourMap = new Color[width * height];

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                // On remplit un tableau 1D (plus rapide que SetPixel)
                // Mathf.Lerp permet de s'assurer que la valeur reste entre 0 et 1
                colourMap[y * width + x] = Color.Lerp(Color.black, Color.white, noiseMap[y, x]);
            }
        }

        // 2. Application des pixels � la texture
        texture.SetPixels(colourMap);
        texture.Apply(); // Tr�s important pour valider les changements

        // 3. Affichage sur le MeshRenderer
        // sharedMaterial permet de voir le r�sultat m�me si on n'est pas en Play Mode
        meshRenderer.sharedMaterial.mainTexture = texture;

        // 4. Ajustement de l'�chelle (on divise souvent par 10 car le Plane Unity fait 10 units)
        this.transform.localScale = new Vector3(width / 10f, 1, height / 10f);
    }
    public void DrawFromMeshMap(Vector3[,] meshMap)
    {
        // on a d�j� la longueur et la hauteur dans le MeshMap
        int width = meshMap.GetLength(0);
        int height = meshMap.GetLenght(1);

        
    }
}