using UnityEngine;

[CreateAssetMenu(fileName = "MeshData", menuName = "Scriptable Objects/MeshData")]
public class MeshData : UpdatableData
{
    public float MeshHeightMultiplier = 10f;
    public AnimationCurve MeshHeightCurve = AnimationCurve.Linear(0, 0, 1, 1);
}
