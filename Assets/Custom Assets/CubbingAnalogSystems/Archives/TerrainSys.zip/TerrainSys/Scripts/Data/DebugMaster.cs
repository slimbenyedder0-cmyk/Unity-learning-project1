using UnityEngine;

public class DebugMaster : MonoBehaviour
{
    enum DebugMode { NoiseMap, Mesh, FalloffMap }
    DebugMode debugMode;
    [Header("Param�tres de la Carte")]
    public int mapWidth = 256;
    public int mapHeight = 256;
    public Vector2 offset;
    public bool autoUpdate = true; // Pour activer/d�sactiver la mise � jour auto

    [Header("R�f�rences")]
    public NoiseData noiseData;
    public DebugDisplayer displayer;

    // Se d�clenche quand on change une valeur dans l'inspecteur du DebugMaster
    void OnValidate()
    {
        if (mapWidth < 1) mapWidth = 1;
        if (mapHeight < 1) mapHeight = 1;

        // On se r�abonne ici au cas o� on changerait de fichier NoiseData dans le slot
        if (noiseData != null)
        {
            // On retire l'ancien abonnement pour �viter les doublons (tr�s important !)
            noiseData.OnValuesUpdated -= OnDataUpdated;
            noiseData.OnValuesUpdated += OnDataUpdated;
        }
    }

    // Cette m�thode est appel�e par l'�v�nement du ScriptableObject
    void OnDataUpdated()
    {
        if (autoUpdate)
        {
            ExecuteCurrentDebugMode();
        }
    }

    [ContextMenu("G�n�rer la Noise Map")]
    public void DebugNoiseMap()
    {
        if (noiseData == null)
        {
            Debug.LogError("NoiseData manquant sur DebugMaster !");
            return;
        }

        float[,] noiseMap = Noise.GenerateNoiseMap(mapWidth, mapHeight, noiseData, offset);

        if (displayer != null)
        {
            displayer.DrawMapFromNoiseMap(noiseMap);
        }
    }
    [ContextMenu("G�n�rer la Mesh Map")]
    public void DebugMeshMap()
    {
        if (noiseData == null)
        {
            Debug.Log ("NoiseData manquant sur DebugMaster !");
        }
        else
        {
            Debug.Log("G�n�ration de la Mesh Map en cours...");
            float[,] noiseMap = Noise.GenerateNoiseMap(mapWidth, mapHeight, noiseData, offset);
            Vector3[,] meshMap = MeshGenerator.GenerateMeshMapFromNoiseMap(noiseMap);
        }
        
    }
    public void ExecuteCurrentDebugMode()
    {
        switch (debugMode)
        {
            case DebugMode.NoiseMap:
                DebugNoiseMap();
                break;
            case DebugMode.Mesh:
                DebugMeshMap();
                break;
            case DebugMode.FalloffMap:
                // Impl�menter le d�bogage de la Falloff Map ici
                break;
        }
    }
}