using UnityEngine;
using System.Collections.Generic;
//// <summary>
/// This class is responsible for generating clusters of star systems within a space sector.
/// All clusters are generated within a cubic sector centered at the origin.
/// 
public class ClusterGenerator
{
    public List<ClusterData> Generate(SpaceSectorData config)
    {
        List<ClusterData> clusters = new List<ClusterData>();

        // Generer gros clusters
        for (int i = 0; i < config.bigClustersCount; i++)
        {
            Vector3 center = GetRandomPositionInSector(config.sectorSize, 0.66f);
            float radius = Random.Range(config.sectorSize * 0.15f, config.sectorSize * 0.25f);
            clusters.Add(new ClusterData(center, radius, true));
        }

        // Generer petits clusters
        for (int i = 0; i < config.smallClustersCount; i++)
        {
            Vector3 center = GetRandomPositionInSector(config.sectorSize, 0.8f);
            float radius = Random.Range(config.sectorSize * 0.05f, config.sectorSize * 0.1f);
            clusters.Add(new ClusterData(center, radius, false));
        }

        // Calculer nombre de systemes par cluster
        int bigClusterSystems = Mathf.RoundToInt(config.targetSystemCount * config.bigClusterRatio);
        int smallClusterSystems = Mathf.RoundToInt(config.targetSystemCount * config.smallClusterRatio);

        int systemsPerBig = config.bigClustersCount > 0 ? bigClusterSystems / config.bigClustersCount : 0;
        int systemsPerSmall = config.smallClustersCount > 0 ? smallClusterSystems / config.smallClustersCount : 0;

        foreach (var cluster in clusters)
            cluster.targetSystemCount = cluster.isBig ? systemsPerBig : systemsPerSmall;

        return clusters;
    }
    /// <summary>
    /// Generates a random position within a cubic sector centered at the origin, with an optional bias toward the
    /// center.
    /// </summary>
    /// <param name="sectorSize">The length of one side of the cubic sector. Must be positive.</param>
    /// <param name="centerBias">A multiplier between 0 and 1 that controls how close the generated position is to the center. Lower values
    /// result in positions closer to the center; 1 uses the full sector size.</param>
    /// <returns>A <see cref="Vector3"/> representing a random position within the specified sector and bias.</returns>
    private Vector3 GetRandomPositionInSector(float sectorSize, float centerBias)
    {
        float range = sectorSize / 2f * centerBias;
        return new Vector3(
            Random.Range(-range, range),
            Random.Range(-range, range),
            Random.Range(-range, range)
        );
    }
}