using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Genere les positions des systemes stellaires avec distribution gaussienne dans les clusters
/// </summary>
public class SystemPositionGenerator
{
    private const int MAX_ATTEMPTS_PER_SYSTEM = 100;

    /// <summary>
    /// Genere toutes les positions des systemes
    /// </summary>
    public List<GeneratedSystem> Generate(SpaceSectorData config, List<ClusterData> clusters)
    {
        List<GeneratedSystem> systems = new List<GeneratedSystem>();

        // ETAPE 1 : Placer les systemes dans les clusters
        foreach (ClusterData cluster in clusters)
        {
            int placed = PlaceSystemsInCluster(config, cluster, systems);
            cluster.actualSystemCount = placed;
        }

        // ETAPE 2 : Placer les systemes dans le vide
        int voidSystemsTarget = config.targetSystemCount - systems.Count;
        PlaceSystemsInVoid(config, clusters, systems, voidSystemsTarget);

        Debug.Log($"SystemPositionGenerator : {systems.Count} systemes places");
        Debug.Log($"  - Dans clusters : {systems.Count - voidSystemsTarget}");
        Debug.Log($"  - Dans le vide : {voidSystemsTarget}");

        return systems;
    }

    /// <summary>
    /// Place les systemes dans un cluster avec distribution gaussienne
    /// </summary>
    private int PlaceSystemsInCluster(SpaceSectorData config, ClusterData cluster, List<GeneratedSystem> existingSystems)
    {
        int placed = 0;
        int attempts = 0;
        int maxAttempts = cluster.targetSystemCount * MAX_ATTEMPTS_PER_SYSTEM;

        while (placed < cluster.targetSystemCount && attempts < maxAttempts)
        {
            Vector3 position = GenerateGaussianPositionInCluster(cluster, config.clusterIntensity);

            if (IsValidPosition(position, config, existingSystems))
            {
                GeneratedSystem system = new GeneratedSystem(position);
                system.parentCluster = cluster;
                existingSystems.Add(system);
                placed++;
            }

            attempts++;
        }

        if (placed < cluster.targetSystemCount)
        {
            Debug.LogWarning($"Cluster {(cluster.isBig ? "GROS" : "PETIT")} : seulement {placed}/{cluster.targetSystemCount} systemes places");
        }

        return placed;
    }

    /// <summary>
    /// Place les systemes dans le vide (hors clusters)
    /// </summary>
    private void PlaceSystemsInVoid(SpaceSectorData config, List<ClusterData> clusters, List<GeneratedSystem> existingSystems, int target)
    {
        int placed = 0;
        int attempts = 0;
        int maxAttempts = target * MAX_ATTEMPTS_PER_SYSTEM;

        while (placed < target && attempts < maxAttempts)
        {
            Vector3 position = GeneratePositionInVoid(config.sectorSize, clusters);

            if (IsValidPosition(position, config, existingSystems))
            {
                GeneratedSystem system = new GeneratedSystem(position);
                system.parentCluster = null; // Pas de cluster parent
                existingSystems.Add(system);
                placed++;
            }

            attempts++;
        }

        if (placed < target)
        {
            Debug.LogWarning($"Vide : seulement {placed}/{target} systemes places");
        }
    }

    /// <summary>
    /// Genere une position avec distribution gaussienne dans un cluster
    /// ALGORITHME : Box-Muller transform pour distribution normale
    /// </summary>
    private Vector3 GenerateGaussianPositionInCluster(ClusterData cluster, float intensity)
    {
        // Calcul de l'ecart-type selon l'intensite
        // Intensite faible = dispersion large
        // Intensite forte = concentration au centre
        float stdDev = cluster.radius / (2f + intensity * 2f);

        // Generer 3 coordonnees gaussiennes
        float x = GaussianRandom(0f, stdDev);
        float y = GaussianRandom(0f, stdDev);
        float z = GaussianRandom(0f, stdDev);

        Vector3 offset = new Vector3(x, y, z);

        // Limiter a l'interieur du cluster (clamp)
        if (offset.magnitude > cluster.radius)
        {
            offset = offset.normalized * cluster.radius;
        }

        return cluster.center + offset;
    }

    /// <summary>
    /// Genere une position dans le vide (evite les clusters)
    /// </summary>
    private Vector3 GeneratePositionInVoid(float sectorSize, List<ClusterData> clusters)
    {
        const int MAX_VOID_ATTEMPTS = 50;

        for (int i = 0; i < MAX_VOID_ATTEMPTS; i++)
        {
            Vector3 position = GetRandomPositionInSector(sectorSize);

            // Verifier que la position n'est pas dans un cluster
            bool inCluster = false;
            foreach (ClusterData cluster in clusters)
            {
                if (cluster.Contains(position))
                {
                    inCluster = true;
                    break;
                }
            }

            if (!inCluster)
            {
                return position;
            }
        }

        // Fallback : retourner une position aleatoire meme si dans un cluster
        return GetRandomPositionInSector(sectorSize);
    }

    /// <summary>
    /// Verifie qu'une position est valide (distance minimale respectee)
    /// </summary>
    private bool IsValidPosition(Vector3 position, SpaceSectorData config, List<GeneratedSystem> existingSystems)
    {
        // Verifier que la position est dans le secteur
        float halfSize = config.sectorSize / 2f;
        if (Mathf.Abs(position.x) > halfSize ||
            Mathf.Abs(position.y) > halfSize ||
            Mathf.Abs(position.z) > halfSize)
        {
            return false;
        }

        // Verifier la distance minimale avec tous les systemes existants
        float minDistSqr = config.minSystemDistance * config.minSystemDistance;

        foreach (GeneratedSystem system in existingSystems)
        {
            float distSqr = (position - system.position).sqrMagnitude;
            if (distSqr < minDistSqr)
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Position aleatoire dans le secteur
    /// </summary>
    private Vector3 GetRandomPositionInSector(float sectorSize)
    {
        float halfSize = sectorSize / 2f;
        return new Vector3(
            Random.Range(-halfSize, halfSize),
            Random.Range(-halfSize, halfSize),
            Random.Range(-halfSize, halfSize)
        );
    }

    /// <summary>
    /// Genere un nombre aleatoire avec distribution gaussienne (normale)
    /// ALGORITHME : Box-Muller transform
    /// 
    /// EXPLICATION :
    /// La transform de Box-Muller convertit deux variables uniformes [0,1]
    /// en deux variables gaussiennes independantes
    /// 
    /// Formule : Z = sqrt(-2 * ln(U1)) * cos(2 * PI * U2)
    /// Ou U1 et U2 sont des randoms uniformes [0,1]
    /// 
    /// Resultat : 
    /// - 68% des valeurs entre [mean - stdDev, mean + stdDev]
    /// - 95% des valeurs entre [mean - 2*stdDev, mean + 2*stdDev]
    /// - 99.7% des valeurs entre [mean - 3*stdDev, mean + 3*stdDev]
    /// </summary>
    private float GaussianRandom(float mean, float stdDev)
    {
        // Generer deux randoms uniformes [0,1]
        float u1 = Random.value;
        float u2 = Random.value;

        // Eviter ln(0)
        if (u1 < 0.0001f) u1 = 0.0001f;

        // Box-Muller transform
        float randStdNormal = Mathf.Sqrt(-2f * Mathf.Log(u1)) * Mathf.Cos(2f * Mathf.PI * u2);

        // Appliquer mean et stdDev
        return mean + stdDev * randStdNormal;
    }

    // === METHODES UTILITAIRES PUBLIQUES ===

    /// <summary>
    /// Calcule la densite locale autour d'une position
    /// Utile pour debug ou visualisation
    /// </summary>
    public float CalculateLocalDensity(Vector3 position, List<GeneratedSystem> systems, float radius)
    {
        int count = 0;
        float radiusSqr = radius * radius;

        foreach (GeneratedSystem system in systems)
        {
            float distSqr = (position - system.position).sqrMagnitude;
            if (distSqr <= radiusSqr)
            {
                count++;
            }
        }

        float volume = (4f / 3f) * Mathf.PI * radius * radius * radius;
        return count / volume;
    }

    /// <summary>
    /// Trouve le systeme le plus proche d'une position
    /// </summary>
    public GeneratedSystem FindNearestSystem(Vector3 position, List<GeneratedSystem> systems)
    {
        if (systems.Count == 0) return null;

        GeneratedSystem nearest = systems[0];
        float minDistSqr = (position - nearest.position).sqrMagnitude;

        for (int i = 1; i < systems.Count; i++)
        {
            float distSqr = (position - systems[i].position).sqrMagnitude;
            if (distSqr < minDistSqr)
            {
                minDistSqr = distSqr;
                nearest = systems[i];
            }
        }

        return nearest;
    }

    /// <summary>
    /// Trouve tous les systemes dans un rayon
    /// </summary>
    public List<GeneratedSystem> FindSystemsInRadius(Vector3 center, float radius, List<GeneratedSystem> systems)
    {
        List<GeneratedSystem> result = new List<GeneratedSystem>();
        float radiusSqr = radius * radius;

        foreach (GeneratedSystem system in systems)
        {
            float distSqr = (center - system.position).sqrMagnitude;
            if (distSqr <= radiusSqr)
            {
                result.Add(system);
            }
        }

        return result;
    }
}
