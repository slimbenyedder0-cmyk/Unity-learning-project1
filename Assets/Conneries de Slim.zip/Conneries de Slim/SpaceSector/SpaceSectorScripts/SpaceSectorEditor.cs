using UnityEngine;
using UnityEditor;
/// Editeur personnalise pour le SpaceSectorGenerator
[CustomEditor(typeof(SpaceSectorGenerator))]
public class SpaceSectorEditor : Editor
{
    public override void OnInspectorGUI()
    {
        SpaceSectorGenerator generator = (SpaceSectorGenerator)target;

        DrawDefaultInspector();

        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("Generation Pas-a-Pas", EditorStyles.boldLabel);

        GUI.enabled = generator.GetState() == SpaceSectorGenerator.GenerationState.None;
        if (GUILayout.Button("1. Generer Clusters", GUILayout.Height(30)))
            generator.Step1_GenerateClusters();

        GUI.enabled = generator.GetState() == SpaceSectorGenerator.GenerationState.ClustersGenerated;
        if (GUILayout.Button("2. Generer Positions", GUILayout.Height(30)))
            generator.Step2_GeneratePositions();

        GUI.enabled = generator.GetState() == SpaceSectorGenerator.GenerationState.PositionsGenerated;
        if (GUILayout.Button("3. Assigner Types", GUILayout.Height(30)))
            generator.Step3_AssignTypes();

        GUI.enabled = generator.GetState() == SpaceSectorGenerator.GenerationState.TypesAssigned;
        if (GUILayout.Button("4. Visualiser", GUILayout.Height(30)))
            generator.Step4_Visualize();

        EditorGUILayout.Space(10);

        GUI.enabled = true;
        GUI.backgroundColor = Color.green;
        if (GUILayout.Button("Generation Complete", GUILayout.Height(40)))
            generator.GenerateComplete();

        GUI.backgroundColor = Color.red;
        if (GUILayout.Button("Effacer", GUILayout.Height(30)))
            generator.Clear();

        GUI.backgroundColor = Color.white;

        EditorGUILayout.Space(10);
        EditorGUILayout.HelpBox($"Etat: {generator.GetState()}", MessageType.Info);
    }
}