using UnityEngine;
/// <summary>
/// Donnees d'un cluster de systemes stellaires
/// </summary>
[System.Serializable]
public class ClusterData
{
    public Vector3 center;
    public float radius;
    public bool isBig;
    public int targetSystemCount;
    public int actualSystemCount;

    public ClusterData(Vector3 center, float radius, bool isBig)
    {
        this.center = center;
        this.radius = radius;
        this.isBig = isBig;
        this.targetSystemCount = 0;
        this.actualSystemCount = 0;
    }

    public bool Contains(Vector3 position)
    {
        return Vector3.Distance(position, center) <= radius;
    }

    public float GetNormalizedDistance(Vector3 position)
    {
        float distance = Vector3.Distance(position, center);
        return Mathf.Clamp01(distance / radius);
    }
}