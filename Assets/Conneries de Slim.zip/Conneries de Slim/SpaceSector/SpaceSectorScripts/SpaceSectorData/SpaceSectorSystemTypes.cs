using UnityEngine;
using System.Collections.Generic;
// ScriptableObject definissant les types de systemes spatiaux dans un secteur spatial
[CreateAssetMenu(fileName = "SystemTypes", menuName = "Space/System Types")]
public class SpaceSectorSystemTypes : ScriptableObject
{
    // Definition d'un type de systeme spatial
    [System.Serializable]
    public class SystemType
    {
        public string name;
        public Color color = Color.white;

        [Range(0f, 1f)]
        public float probability;

        public float realSize = 1f;
        public float visualSizeMultiplier = 1f;

        [TextArea(2, 4)]
        public string description;
    }

    public List<SystemType> types = new List<SystemType>();
    // Normalizes the probabilities of all SystemTypes to ensure they sum to 1.
    public void NormalizeProbabilities()
    {
        float sum = 0f;
        foreach (var type in types)
            sum += type.probability;

        if (sum > 0)
        {
            foreach (var type in types)
                type.probability /= sum;
        }
    }
    // Selects a random SystemType based on their defined probabilities.
    public SystemType SelectRandomType()
    {
        if (types.Count == 0) return null;

        float roll = Random.value;
        float cumulative = 0f;

        foreach (var type in types)
        {
            cumulative += type.probability;
            if (roll <= cumulative)
                return type;
        }

        return types[0];
    }
    // Validates that the sum of probabilities is approximately 1 and logs a warning if not.
    private void OnValidate()
    {
        float sum = 0f;
        foreach (var type in types)
            sum += type.probability;

        if (Mathf.Abs(sum - 1f) > 0.01f)
            Debug.LogWarning($"Somme des probabilites: {sum:F3} (devrait etre 1.0)");
    }
}