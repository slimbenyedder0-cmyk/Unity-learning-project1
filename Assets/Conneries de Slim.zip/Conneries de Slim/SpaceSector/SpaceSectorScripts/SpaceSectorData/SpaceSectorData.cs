using UnityEngine;
/// <summary>
/// Ce ScriptableObject contient les parametres de generation d'un secteur spatial
/// "Taille et Limites", "Contraintes", "Clustering", "Distribution", "Echelle Visuelle JRPG", "References"
/// Respecte les contraintes de taille, densite, distance minimale entre systemes, etc.
/// </summary>
[CreateAssetMenu(fileName = "SpaceSectorData", menuName = "Space/Sector Data")]
public class SpaceSectorData : ScriptableObject
{
    [Header("Taille et Limites")]
    [Range(1f, 10.5f)]
    public float sectorSize = 100f;

    [Range(0, 1500)]
    public int targetSystemCount = 500;

    [Header("Contraintes")]
    public float maxDensity = 1.2f;
    public int maxSystemsAbsolute = 1500;
    public float minSystemDistance = 20f;

    [Header("Clustering")]
    [Range(1, 3)]
    public int bigClustersCount = 2;

    [Range(3, 5)]
    public int smallClustersCount = 4;

    [Range(0f, 1f)]
    public float clusterIntensity = 0.7f;

    [Header("Distribution")]
    [Range(0f, 1f)]
    public float bigClusterRatio = 0.35f;

    [Range(0f, 1f)]
    public float smallClusterRatio = 0.25f;

    public float VoidRatio => 1f - bigClusterRatio - smallClusterRatio;

    [Header("Echelle Visuelle JRPG")]
    public float visualScaleFactor = 1.5f;
    public float minVisualSize = 0.5f;
    public float maxVisualSize = 5.0f;

    [Header("References")]
    public SpaceSectorSystemTypes systemTypes;
    public GameObject systemPrefab;

    // Proprietes calculees
    public float Volume => sectorSize * sectorSize * sectorSize;
    public int MaxSystemsByDensity => Mathf.FloorToInt(Volume * maxDensity);
    public int ActualMaxSystems => Mathf.Min(MaxSystemsByDensity, maxSystemsAbsolute);
    public float MaxSectorSize => Mathf.Pow(maxSystemsAbsolute / maxDensity, 1f / 3f);

    public void OnValidate()
    {
        float maxSize = MaxSectorSize;
        if (sectorSize > maxSize)
            sectorSize = maxSize;

        int maxSystems = ActualMaxSystems;
        if (targetSystemCount > maxSystems)
            targetSystemCount = maxSystems;

        float totalRatio = bigClusterRatio + smallClusterRatio;
        if (totalRatio > 1f)
        {
            float scale = 1f / totalRatio;
            bigClusterRatio *= scale;
            smallClusterRatio *= scale;
        }
    }
}