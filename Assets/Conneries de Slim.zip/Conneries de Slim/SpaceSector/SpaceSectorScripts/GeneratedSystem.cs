using UnityEngine;

[System.Serializable]
public class GeneratedSystem
{
    public Vector3 position;
    public SpaceSectorSystemTypes.SystemType type;
    public ClusterData parentCluster;
    public GameObject gameObject;
    public string systemName;

    public GeneratedSystem(Vector3 position)
    {
        this.position = position;
    }
}