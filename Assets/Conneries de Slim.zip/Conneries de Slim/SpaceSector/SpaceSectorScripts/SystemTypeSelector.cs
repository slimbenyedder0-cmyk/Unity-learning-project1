using UnityEngine;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Attribue des types de syst�mes (classes spectrales, raret�) aux positions g�n�r�es
/// en fonction des probabilit�s d�finies dans la configuration.
/// </summary>
public class SystemTypeSelector
{
    /// <summary>
    /// Assigne un type � chaque syst�me g�n�r�.
    /// </summary>
    public void AssignTypes(List<GeneratedSystem> systems, SpaceSectorData config)
    {
        if (systems == null || systems.Count == 0) return;
        if (config.systemTypeWeights == null || config.systemTypeWeights.Count == 0)
        {
            Debug.LogError("SystemTypeSelector : Aucune pond�ration de type de syst�me dans la config !");
            return;
        }

        // 1. Pr�parer les poids (calculer la somme totale pour la normalisation)
        float totalWeight = 0f;
        foreach (var weight in config.systemTypeWeights)
        {
            totalWeight += weight.probabilityWeight;
        }

        // 2. Assigner les types
        foreach (GeneratedSystem system in systems)
        {
            system.type = GetWeightedRandomType(config.systemTypeWeights, totalWeight);

            // Logique optionnelle : On peut ajuster le type selon si le syst�me 
            // est dans un cluster ou dans le vide
            ApplyContextualModifiers(system);
        }

        Debug.Log($"SystemTypeSelector : Types assign�s � {systems.Count} syst�mes.");
    }

    /// <summary>
    /// S�lectionne un type de syst�me bas� sur les poids de probabilit�
    /// </summary>
    private SystemType GetWeightedRandomType(List<SystemWeightData> weights, float totalWeight)
    {
        float roll = Random.Range(0f, totalWeight);
        float cumulative = 0f;

        foreach (var weight in weights)
        {
            cumulative += weight.probabilityWeight;
            if (roll <= cumulative)
            {
                return weight.systemType;
            }
        }

        return weights[0].systemType; // Fallback
    }

    /// <summary>
    /// Permet d'ajuster les propri�t�s du syst�me selon son environnement
    /// </summary>
    private void ApplyContextualModifiers(GeneratedSystem system)
    {
        // Exemple : Les syst�mes dans le vide (parentCluster == null) 
        // pourraient avoir plus de chances d'�tre instables ou isol�s.
        if (system.parentCluster == null)
        {
            system.isIsolated = true;
        }
        else if (system.parentCluster.isBig)
        {
            // Les gros clusters pourraient influencer la richesse des syst�mes
            system.resourceMultiplier = 1.2f;
        }
    }
}

// --- Structures de donn�es n�cessaires (si non d�finies ailleurs) ---

[System.Serializable]
public class SystemWeightData
{
    public SystemType systemType;
    public float probabilityWeight; // Ex: 80 pour Commun, 1 pour Rare
}

public enum SystemType
{
    Star_Type_M, // Naine rouge (Commun)
    Star_Type_G, // Type Soleil
    Star_Type_O, // G�ante bleue (Rare)
    WhiteDwarf,
    BlackHole,
    NeutronStar
}

/* // Note : Ta classe GeneratedSystem devrait ressembler � ceci :
public class GeneratedSystem 
{
    public Vector3 position;
    public ClusterData parentCluster;
    public SystemType type;
    public bool isIsolated;
    public float resourceMultiplier = 1.0f;

    public GeneratedSystem(Vector3 pos) {
        position = pos;
    }
}
*/