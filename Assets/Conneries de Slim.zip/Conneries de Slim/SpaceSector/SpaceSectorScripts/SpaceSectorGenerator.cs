using UnityEngine;
using System.Collections.Generic;
/// <summary>
/// Script principal de generation d'un secteur spatial
/// </summary>
public class SpaceSectorGenerator : MonoBehaviour
{
    [Header("Configuration")]
    public SpaceSectorData config;
    /// <summary>
    /// Gets or sets the current generation state.
    /// </summary>
    [Header("Etat de Generation")]
    [SerializeField] private GenerationState currentState = GenerationState.None;
    [SerializeField] private int generatedSystemsCount = 0;

    private ClusterGenerator clusterGenerator;
    private SystemPositionGenerator positionGenerator;
    private SystemTypeSelector typeSelector;
    private SpaceSectorVisualizer visualizer;

    private List<ClusterData> clusters = new List<ClusterData>();
    private List<GeneratedSystem> systems = new List<GeneratedSystem>();
    /// <summary>
    /// Specifies the current stage of the generation process.
    /// </summary>
    /// <remarks>Use this enumeration to track or control the progress of a multi-step generation workflow.
    /// The values represent sequential phases, from no progress (<see cref="None"/>) to completion (<see
    /// cref="Complete"/>).</remarks>
    public enum GenerationState
    {
        None,
        ClustersGenerated,
        PositionsGenerated,
        TypesAssigned,
        Visualized,
        Complete
    }
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    private void Awake()
    {
        InitializeModules();
    }
    /// <summary>
    /// Initializes the generation modules.
    /// </summary>
    private void InitializeModules()
    {
        clusterGenerator = new ClusterGenerator();
        positionGenerator = new SystemPositionGenerator();
        typeSelector = new SystemTypeSelector();
        visualizer = GetComponent<SpaceSectorVisualizer>();

        if (visualizer == null)
            visualizer = gameObject.AddComponent<SpaceSectorVisualizer>();
    }
    /// <summary>
    /// Validates the configuration when changes are made in the inspector.
    /// </summary>
    private void OnValidate()
    {
        if (config != null)
            config.OnValidate();
    }
    /// <summary>
    /// Generates the entire space sector in one go.
    /// </summary>
    public void GenerateComplete()
    {
        Clear();
        Step1_GenerateClusters();
        Step2_GeneratePositions();
        Step3_AssignTypes();
        Step4_Visualize();
        currentState = GenerationState.Complete;
    }
    /// <summary>
    /// Generates clusters based on the configuration.
    /// </summary>
    public void Step1_GenerateClusters()
    {
        if (config == null)
        {
            Debug.LogError("Config manquante !");
            return;
        }
        /// Generate clusters
        clusters = clusterGenerator.Generate(config);
        currentState = GenerationState.ClustersGenerated;
        Debug.Log($"Clusters generes : {clusters.Count}");
    }
    /// <summary>
    /// Generates system positions within the generated clusters.
    /// </summary>
    public void Step2_GeneratePositions()
    {
        if (currentState < GenerationState.ClustersGenerated)
        {
            Debug.LogError("Generez d'abord les clusters !");
            return;
        }

        systems = positionGenerator.Generate(config, clusters);
        generatedSystemsCount = systems.Count;
        currentState = GenerationState.PositionsGenerated;
        Debug.Log($"Positions generees : {systems.Count}");
    }
    /// <summary>
    /// Generates system types for the generated systems.
    /// </summary>
    public void Step3_AssignTypes()
    {
        if (currentState < GenerationState.PositionsGenerated)
        {
            Debug.LogError("Generez d'abord les positions !");
            return;
        }
        /// Assign types to the generated systems
        typeSelector.AssignTypes(config, systems);
        currentState = GenerationState.TypesAssigned;
        Debug.Log("Types assignes");
    }
    /// <summary>
    /// Generates the visualization of the space sector.
    /// </summary>
    public void Step4_Visualize()
    {
        if (currentState < GenerationState.TypesAssigned)
        {
            Debug.LogError("Assignez d'abord les types !");
            return;
        }
        /// Visualize the generated systems
        visualizer.Clear();
        visualizer.Visualize(config, systems, clusters);
        currentState = GenerationState.Visualized;
        Debug.Log("Visualisation complete");
    }
    /// <summary>
    /// Clears all generated data and resets the generator state.
    /// </summary>
    public void Clear()
    {
        clusters.Clear();
        systems.Clear();
        generatedSystemsCount = 0;
        currentState = GenerationState.None;

        if (visualizer != null)
            visualizer.Clear();
    }
    /// <summary>
    /// Gets the list of clusters currently managed by the instance.
    /// </summary>
    /// <returns>A list of <see cref="ClusterData"/> objects representing the current clusters. The list may be empty if no
    /// clusters are available.</returns>
    public List<ClusterData> GetClusters() => clusters;
    public List<GeneratedSystem> GetSystems() => systems;
    public GenerationState GetState() => currentState;
}